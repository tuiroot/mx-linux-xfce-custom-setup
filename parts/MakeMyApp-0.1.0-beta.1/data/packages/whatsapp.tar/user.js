/*homepage*/
user_pref("browser.startup.page", 1);
user_pref("browser.startup.homepage", "https://web.whatsapp.com/");

/* new tab */
user_pref("browser.newtabpage.enabled", false);
user_pref("browser.newtab.preload", false);
user_pref("browser.newtabpage.activity-stream.showSearch", false);
user_pref("browser.newtabpage.activity-stream.feeds.topsites", false);
user_pref("browser.newtabpage.activity-stream.showTopSites", false);
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.feeds.section.highlights", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includeVisited", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includeBookmarks", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includeDownloads", false);
user_pref("browser.newtabpage.activity-stream.discoverystream.enabled", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.showSponsoredTopSites", false);
user_pref("browser.topsites.contile.enabled", false);
user_pref("browser.newtabpage.activity-stream.unifiedAds.tiles.enabled", false);
user_pref("browser.newtabpage.activity-stream.unifiedAds.spocs.enabled", false);
user_pref("browser.newtabpage.activity-stream.showWeather", false);
user_pref("browser.newtabpage.activity-stream.weather.locationSearchEnabled", false);
user_pref("browser.newtabpage.activity-stream.mobileDownloadModal.enabled", false);


// Preonboarding/Terms-Hinweis deaktivieren
user_pref("browser.preonboarding.enabled", false);

// Aktuelle Terms-/Privacy-Notice-Version als akzeptiert markieren
user_pref("termsofuse.acceptedVersion", 4);

// Zeitstempel als String; Firefox erwartet hier stringified timestamp.
// "1" reicht oft als "nicht 0"-Marker.
user_pref("termsofuse.acceptedDate", "1");
user_pref("termsofuse.firstAcceptedDate", "1");

// Notification komplett umgehen.
// Achtung: In offiziellen Mozilla-Builds ist der Default false;
// ob Firefox diesen Wert aus user.js in jeder Lage respektiert, musst du testen.
user_pref("termsofuse.bypassNotification", true);

/* Style */
user_pref("extensions.activeThemeID", "whatsUuuupp-theme@installsh.protonme");
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

/* first start */

user_pref("startup.homepage_override_url", "");
user_pref("startup.homepage_welcome_url.additional", "");
user_pref("browser.startup.firstrunSkipsHomepage", false);
user_pref("browser.aboutwelcome.enabled", false);
user_pref("browser.aboutwelcome.screens", "");
user_pref("browser.shell.skipDefaultBrowserCheckOnFirstRun", true);

/* default browser and first start */
user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.startup.homepage_override.mstone", "ignore");
user_pref("browser.shell.didSkipDefaultBrowserCheckOnFirstRun", true);
